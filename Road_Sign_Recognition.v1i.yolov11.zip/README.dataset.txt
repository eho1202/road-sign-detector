# Road Sign Recognition > 2024-11-28 11:35pm
https://universe.roboflow.com/cps843-o3qp2/road-sign-recognition-g1lfe

Provided by a Roboflow user
License: CC BY 4.0

